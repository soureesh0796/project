package com.room.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Room implements Serializable{
	public static final long serialVersionUID = 1L;
	
	private
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	
	int roomNumber;
	
	@OneToMany(mappedBy = "room", cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	private List<Booking> bookingList=new ArrayList<>();
	
	public Room(){}

	public Room(int id, int roomNumber, List<Booking> bookingList) {
		super();
		this.id = id;
		this.roomNumber = roomNumber;
		this.bookingList = bookingList;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}

	public List<Booking> getBookingList() {
		return bookingList;
	}

	public void setBookingList(List<Booking> bookingList) {
		this.bookingList = bookingList;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
