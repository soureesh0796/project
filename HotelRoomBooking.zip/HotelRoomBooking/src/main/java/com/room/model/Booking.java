package com.room.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Booking implements Serializable{
	public static final long serialVersionUID = 1L;
	
	private
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int booking_id;
	String bookingDate;
	String status;
	
	@ManyToOne
	private Room room;
	
	public Booking() {}

	public Booking(int booking_id, String bookingDate, String status, Room room) {
		super();
		this.booking_id = booking_id;
		this.bookingDate = bookingDate;
		this.status = status;
		this.room = room;
	}

	public int getBooking_id() {
		return booking_id;
	}

	public void setBooking_id(int booking_id) {
		this.booking_id = booking_id;
	}

	public String getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		this.room = room;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
