package com.room.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.room.dao.RoomDao;
import com.room.model.Booking;
import com.room.model.Room;

@Service("roomBo")
public class RoomBoImpl implements RoomBo{
	
	@Autowired(required=true)
	private RoomDao roomDao;

	@Override
	public void addRoom() {
		Room room1=new Room();
		room1.setRoomNumber(1001);
		roomDao.addRoom(room1);
		
		Room room2=new Room();
		room2.setRoomNumber(1002);
		roomDao.addRoom(room2);
	}

	@Override
	public List<Room> displayRooms() {
		List<Room> roomList=roomDao.viewRooms();
		return roomList;
	}

	@Override
	public List<Booking> showRooms() {
		List<Booking> roomList=roomDao.showRooms();
		return roomList;
	}

}
