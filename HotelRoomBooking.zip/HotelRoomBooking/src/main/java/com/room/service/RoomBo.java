package com.room.service;

import java.util.List;

import com.room.model.Booking;
import com.room.model.Room;

public interface RoomBo {
	
	public void addRoom();
	
	public List<Room> displayRooms();

	public List<Booking> showRooms();

}
