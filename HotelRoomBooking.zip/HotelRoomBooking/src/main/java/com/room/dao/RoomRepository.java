package com.room.dao;

import org.springframework.data.repository.CrudRepository;

import com.room.model.Room;

public interface RoomRepository extends CrudRepository<Room, Integer>{

}
