package com.room.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.room.model.Booking;
import com.room.model.Room;

@Repository("roomDao")
public class RoomDaoImpl implements RoomDao{

	@Autowired
	RoomRepository roomRep;
	
	@Autowired
	BookingRepository bookingRep;

	@Override
	public void addRoom(Room room) {
		roomRep.save(room);
	}

	@Override
	public List<Room> viewRooms() {
		List<Room> roomList=new ArrayList<Room>();
		roomRep.findAll().forEach(roomList::add);
		return roomList;
	}

	@Override
	public List<Booking> showRooms() {
		List<Booking> bookedList=new ArrayList<>();
		bookingRep.findAll().forEach(bookedList::add);
		return bookedList;
	}
}
