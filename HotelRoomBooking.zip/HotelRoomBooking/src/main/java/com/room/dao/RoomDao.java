package com.room.dao;

import java.util.List;

import com.room.model.Booking;
import com.room.model.Room;

public interface RoomDao {

	public void addRoom(Room room);

	public List<Room> viewRooms();

	public List<Booking> showRooms();

}
