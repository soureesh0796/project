package com.room.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.room.model.Booking;
import com.room.model.Room;
import com.room.service.RoomBo;

@Controller
public class RoomController {
	
	@Autowired(required=true)
	private RoomBo roomBo;
	
	@RequestMapping("/")
	public String homePage(Model model) {
		//roomBo.addRoom();
		List<Room> roomList=roomBo.displayRooms();
		for(Room r:roomList)
		{
			System.out.println(r.getRoomNumber());
		}
		model.addAttribute("roomList",roomList);
		return "Booking";
	}
	
	@RequestMapping(value="/checkAvailability", method=RequestMethod.POST)
	@ResponseBody
	public List<Booking> showRooms(){
		return roomBo.showRooms();
	}
	
	


}
